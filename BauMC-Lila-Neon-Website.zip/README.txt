BAUMC WEBSITE – LILA NEON
Dateien: index.html (Start), ranks.html (Ränge), news.html (News), sup.html (SUP), discord.html (Discord), styles.css, script.js.

INSTALLATION:
1. Öffne das Repository BauMC-Website-Neu.
2. Lade ALLE Dateien aus diesem ZIP in den Hauptordner (Root) hoch.
3. Ersetze die alte index.html, styles.css und script.js; füge ranks.html, news.html, sup.html und discord.html hinzu.
4. Commit changes.
5. Settings > Pages: Deploy from a branch, Branch main, Folder /(root).
6. Warte einige Minuten, dann Website neu laden.

ANPASSEN:
- index.html: Ersetze DEINE-SERVER-IP-HIER durch deine echte Server-IP.
- discord.html: Ersetze https://discord.com/ durch deinen Discord-Einladungslink.

DISCORD-WEBHOOK:
In script.js ist WEBHOOK_URL absichtlich leer. Wenn leer, zeigt das Formular eine verständliche Meldung. Wenn du einen Webhook einträgst, ist er öffentlich sichtbar und kann missbraucht werden. Verwende nur einen eigens dafür erstellten Webhook und erneuere/lösche ihn, wenn er bekannt wird. GitHub Pages kann allein keine sichere private Verbindung zu Discord herstellen und keine News dauerhaft speichern.
