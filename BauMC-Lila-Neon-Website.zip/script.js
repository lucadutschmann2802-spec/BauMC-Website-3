// Statische GitHub-Pages-Version. Ein Webhook im Browsercode ist öffentlich.
const WEBHOOK_URL = ""; // Optional: Discord-Webhook hier eintragen. Jeder Besucher kann ihn sehen.
function showStatus(id, message, error=false){const el=document.getElementById(id);if(el){el.textContent=message;el.classList.toggle("error",error)}}
async function sendWebhook(payload,statusId){
 if(!WEBHOOK_URL.trim()){showStatus(statusId,"Noch nicht mit Discord verbunden: Der Webhook wurde nicht eingetragen.",true);return}
 try{const r=await fetch(WEBHOOK_URL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});if(!r.ok)throw new Error();showStatus(statusId,"Erfolgreich an Discord gesendet!")}
 catch(e){showStatus(statusId,"Senden fehlgeschlagen. Bitte Webhook prüfen.",true)}
}
document.addEventListener("DOMContentLoaded",()=>{
 const sf=document.getElementById("support-form");
 if(sf)sf.addEventListener("submit",async e=>{e.preventDefault();const name=document.getElementById("support-name").value.trim(),cat=document.getElementById("support-category").value,msg=document.getElementById("support-message").value.trim();if(!name||!msg){showStatus("support-status","Bitte fülle alle Pflichtfelder aus.",true);return}const b=sf.querySelector("button[type=submit]");b.disabled=true;b.textContent="Wird gesendet…";await sendWebhook({content:"**Neue BauMC-SUP-Anfrage**\\n**Name:** "+name+"\\n**Kategorie:** "+cat+"\\n**Nachricht:** "+msg},"support-status");b.disabled=false;b.textContent="SUP-Nachricht absenden"});
 const nf=document.getElementById("news-form");
 if(nf)nf.addEventListener("submit",async e=>{e.preventDefault();const title=document.getElementById("news-title").value.trim(),body=document.getElementById("news-body").value.trim();if(!title||!body){showStatus("news-status","Bitte Titel und Nachricht ausfüllen.",true);return}const b=nf.querySelector("button[type=submit]");b.disabled=true;b.textContent="Wird gesendet…";await sendWebhook({content:"**BauMC-News-Vorschlag**\\n**Titel:** "+title+"\\n**Text:** "+body},"news-status");b.disabled=false;b.textContent="News-Vorschlag senden"});
});
